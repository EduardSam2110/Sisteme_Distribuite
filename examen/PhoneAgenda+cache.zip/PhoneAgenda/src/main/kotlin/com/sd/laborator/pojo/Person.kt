package com.sd.laborator.pojo

data class Person(
    var id: Int = 0,
    var lastName: String = "",
    var firstName: String = "",
    var telephoneNumber: String = ""
)